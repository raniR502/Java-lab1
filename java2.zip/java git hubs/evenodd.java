// Java Program to Check if Given Integer is Odd or Even
// Using Brute Forcew Approach
public class evenodd {

	public static void main(String[] args)
	{
		int num = 10;
		if (num % 2 == 0) {

			System.out.println("Entered Number is Even");
		}

		else {

			System.out.println("Entered Number is Odd");
		}
	}
}

