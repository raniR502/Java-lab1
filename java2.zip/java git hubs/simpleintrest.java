// Java program to compute
// simple interest for given principal
// amount, time and rate of interest.

public class simpleintrest {
    public static void main(String args[])
    {
        float P = 1, R = 1, T = 1;
        float SI = (P * T * R) / 100;
        System.out.println("Simple interest = " + SI);
    }
}

