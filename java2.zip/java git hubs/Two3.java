// Java Program to print Multiplication of two floating
// point Number.

public class Two3 {
	public static void main(String[] args)
	{

		float f1 = 1.5f;
		float f2 = 2.0f;

		float p = f1 * f2;

		System.out.println("The product is: " + p);
	}
}

    

